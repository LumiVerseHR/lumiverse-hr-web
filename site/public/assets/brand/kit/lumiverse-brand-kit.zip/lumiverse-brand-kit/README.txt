LumiVerse brand kit
Generated 2026-10-21. Guide: https://lumiverse.hr/brand-guide  Assets: https://lumiverse.hr/brand-guide/assets

logo/       Lockups, symbol and wordmark as SVG; transparent PNG logos for invoicing tools.
icons/      Favicons, app icons and profile pictures.
social/     Covers and share cards at each network's size.
documents/  Letterhead, memo (EN/HR) and business card. Install fonts/ before editing the DOCX files.
email/      Signature logo and paste-ready HTML signature.
meetings/   Video call background and slide backgrounds.
ads/        Display ads.
fonts/      Golos Text and Barlow Condensed (SIL Open Font License, free to install and share).

Colours: coral #ff4d4d, gallery wall #0e0f12, text #f7f7f6. Use the files as they are; do not redraw, stretch or recolour the logo.
